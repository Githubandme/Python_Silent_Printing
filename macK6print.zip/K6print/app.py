# 兼容打包路径和中文目录
import sys
import os
import tempfile
import requests
from flask import Flask, request, jsonify
import subprocess
import shutil
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import asyncio
import websockets
import pystray
from PIL import Image, ImageDraw, ImageTk
import uuid

"""
全局变量声明，确保跨线程/函数访问
"""
root = None
status_icon_label = None
status_text_label = None
port_value_label = None
ws_port_value_label = None
logbox = None
tray_icon_instance = None
tk_icons = {}

is_printing = False  # 打印中状态

# 获取程序运行路径
if getattr(sys, 'frozen', False):
    # 如果是打包后的应用
    BASE_DIR = os.path.dirname(sys.executable)
    APP_EXEC_PATH = sys.executable
else:
    # 如果是直接运行的.py文件
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    APP_EXEC_PATH = f"python3 {os.path.abspath(sys.argv[0])}"

LOG_FILE = os.path.join(BASE_DIR, 'print.log')
CACHE_DIR = os.path.join(BASE_DIR, 'pdf_cache')
MAX_CACHE = 5

app = Flask(__name__)
PRINT_ALLOWED = True
PRINT_PAUSED = False
PORT = 12345  # Flask HTTP 端口
WS_PORT = 12346  # WebSocket 独立端口，需与前端 ws://localhost:12346 保持一致
current_paper_size = '' # This variable is not used to control paper size, it's fixed below

def log(msg):
    try:
        # 先读取现有日志，保留最后99条
        lines = []
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'r', encoding='utf-8') as f:
                lines = f.readlines()[-99:]
        # 新日志追加
        lines.append(f"{datetime.now()} {msg}\n")
        with open(LOG_FILE, 'w', encoding='utf-8') as f:
            f.writelines(lines)
    except Exception as e:
        print(f"[日志写入异常] {e}。缓存/日志目录无写入权限，请检查文件夹权限。", file=sys.stderr)
    # 实时刷新日志到GUI
    global root, logbox
    if logbox and root:
        root.after(0, lambda: _update_logbox(msg))

def _update_logbox(msg):
    global logbox
    if logbox:
        logbox.insert(tk.END, f"{datetime.now()} {msg}\n")
        logbox.see(tk.END)

def get_printers():
    """获取系统可用打印机列表"""
    try:
        # 使用 lpstat 命令获取打印机列表 (macOS)
        result = subprocess.run(['lpstat', '-p'], capture_output=True, text=True, timeout=10)
        printers = []
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if line.startswith('printer'):
                    # 提取打印机名称
                    parts = line.split()
                    if len(parts) >= 2:
                        printers.append(parts[1])
        return printers
    except Exception as e:
        log(f"获取打印机列表失败: {e}")
        return []

def download_pdf(url):
    """下载PDF文件到缓存目录"""
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        if not os.path.exists(CACHE_DIR):
            os.makedirs(CACHE_DIR)
        
        filename = f"{uuid.uuid4()}.pdf"
        filepath = os.path.join(CACHE_DIR, filename)
        
        with open(filepath, 'wb') as f:
            f.write(response.content)
        
        clean_cache()
        return filepath
    except Exception as e:
        log(f"下载PDF失败: {url}, 错误: {str(e)}")
        raise Exception(f"下载PDF失败: {str(e)}")

def clean_cache():
    """清理缓存文件，保留最新的MAX_CACHE个文件"""
    try:
        if not os.path.exists(CACHE_DIR):
            return
            
        files = [(f, os.path.getctime(os.path.join(CACHE_DIR, f))) 
                for f in os.listdir(CACHE_DIR) if f.endswith('.pdf')]
        files.sort(key=lambda x: x[1], reverse=True)
        
        # 删除超出缓存数量的文件
        for f, _ in files[MAX_CACHE:]:
            os.remove(os.path.join(CACHE_DIR, f))
    except Exception as e:
        log(f"清理缓存失败: {e}")

@app.route('/print', methods=['POST'])
def print_pdf():
    global PRINT_ALLOWED, PRINT_PAUSED, is_printing
    try:
        if not PRINT_ALLOWED or PRINT_PAUSED:
            log('打印被暂停或禁止')
            return jsonify({'status': 'error', 'message': '打印被暂停或禁止'}), 403
        
        data = request.json
        pdf_url = data.get('pdfUrl')
        printer_name = data.get('printerName')
        
        # 参数类型校验
        if not isinstance(pdf_url, str) or (printer_name is not None and not isinstance(printer_name, str)):
            log('参数类型错误，请检查接口调用方式。')
            return jsonify({'status': 'error', 'message': '参数类型错误，请检查接口调用方式。'}), 400
        
        # 强制所有打印任务都用 100*150mm 纸张
        paper_size = '100x150mm'

        if not pdf_url:
            log('打印失败：未提供pdfUrl。建议：检查接口调用参数。')
            return jsonify({'status': 'error', 'message': 'pdfUrl required。建议：检查接口参数。'}), 400
        
        # 每次都下载，不允许缓存打印
        try:
            is_printing = True
            if hasattr(start_gui, 'set_tray_blink'):
                start_gui.set_tray_blink(True)

            if pdf_url.startswith('http://') or pdf_url.startswith('https://'):
                temp_pdf = download_pdf(pdf_url)
            else:
                temp_pdf = os.path.join(CACHE_DIR, f"{uuid.uuid4()}.pdf")
                try:
                    shutil.copy(pdf_url, temp_pdf)
                except Exception as e:
                    log(f'本地PDF拷贝失败：{pdf_url}，错误：{str(e)}。请检查文件路径和权限。')
                    raise Exception(f'本地PDF拷贝失败：{str(e)}。建议：检查文件路径、权限。')
                clean_cache()
            
            # 构建打印命令 (使用 lp 命令进行打印)
            cmd = ['lp', '-o', f'PageSize={paper_size}']
            
            # 如果指定了打印机，则添加打印机参数
            if printer_name:
                # 验证打印机是否存在
                if printer_name not in get_printers():
                    log(f'打印机名称无效：{printer_name}。请检查打印机是否连接、名称是否正确。')
                    raise Exception(f'打印机名称无效：{printer_name}。建议：检查打印机连接和名称。')
                cmd.extend(['-d', printer_name])
            
            # 添加PDF文件路径
            cmd.append(temp_pdf)
            
            log(f'最终执行命令: {" ".join(cmd)}')
            
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60, check=False)
            except subprocess.TimeoutExpired:
                is_printing = False
                if hasattr(start_gui, 'set_tray_blink'):
                    start_gui.set_tray_blink(False)
                log(f'打印超时：{pdf_url}，建议检查打印机连接和状态。')
                return jsonify({'status': 'error', 'message': '打印超时，建议检查打印机连接和状态。'}), 504
            except OSError as e:
                is_printing = False
                if hasattr(start_gui, 'set_tray_blink'):
                    start_gui.set_tray_blink(False)
                log(f'打印命令无法执行，错误：{e}')
                return jsonify({'status': 'error', 'message': '打印命令无法执行，请检查系统打印服务。'}), 500
            
            finally:
                is_printing = False
                if hasattr(start_gui, 'set_tray_blink'):
                    start_gui.set_tray_blink(False)

            if result.returncode == 0:
                log(f'打印成功：{pdf_url} -> {printer_name or "默认打印机"} 纸张:{paper_size} 缓存:{temp_pdf}')
                return jsonify({'status': 'ok', 'message': result.stdout, 'cachePath': temp_pdf})
            else:
                # PDF损坏或格式不支持检测
                err_msg = result.stderr.lower()
                if 'invalid' in err_msg or 'corrupt' in err_msg:
                    log(f'PDF文件损坏或格式不受支持：{pdf_url}。建议重新生成或检查源文件。')
                    return jsonify({'status': 'error', 'message': 'PDF文件损坏或格式不受支持，建议重新生成或检查源文件。', 'cachePath': temp_pdf})
                
                log(f'打印失败：{pdf_url} -> {printer_name or "默认打印机"}，错误：{result.stderr} 缓存:{temp_pdf}。建议：检查打印机状态、纸张、驱动。')
                return jsonify({'status': 'error', 'message': result.stderr + "。建议：检查打印机状态、纸张、驱动。", 'cachePath': temp_pdf})
        except Exception as e:
            is_printing = False
            if hasattr(start_gui, 'set_tray_blink'):
                start_gui.set_tray_blink(False)
            log(f'打印异常：{pdf_url}，错误：{str(e)}。如多次出现此类错误，请联系技术支持。')
            return jsonify({'status': 'error', 'message': str(e) + "。如多次出现此类错误，请联系技术支持。"})
    except Exception as e:
        log(f'未知错误：{str(e)}')
        return jsonify({'status': 'error', 'message': f'未知错误：{str(e)}'})

def run_flask():
    global PORT
    try:
        app.run(host='127.0.0.1', port=PORT)
    except OSError as e:
        log(f'HTTP服务启动失败：{e}。端口被占用，请更换端口或关闭占用程序。重启软件后请按F5刷新打印网站。')
        print(f'[ERROR] HTTP服务启动失败：{e}。端口被占用，请更换端口或关闭占用程序。重启软件后请按F5刷新打印网站。', file=sys.stderr)

# 原生 WebSocket 服务端实现
import websockets.exceptions
async def ws_handler(websocket):
    global PRINT_ALLOWED, PRINT_PAUSED
    try:
        async for message in websocket:
            print(f"[DEBUG] 收到原始消息: {message}")
            import json
            import urllib.parse
            # 先尝试URL解码
            try:
                decoded = urllib.parse.unquote(message)
                print(f"[DEBUG] URL解码后: {decoded}")
                data = json.loads(decoded)
            except Exception:
                # 兼容前端直接发送字符串指令的情况
                msg = message.strip().lower()
                if msg == 'getprinterlist':
                    data = {'method': 'getprinterlist'}
                elif msg == 'get_printers':
                    data = {'method': 'get_printers'}
                else:
                    await websocket.send(json.dumps({'status': 'error', 'message': '数据格式错误'}))
                    continue

            # 兼容网站前端JS：获取打印机列表
            if data.get('method') == 'getprinterlist':
                printers = get_printers()
                # 构造兼容前端的返回格式，增加 printers 字段，最大兼容
                resp = {
                    'method': 'getprinterlist',
                    'status': 'ok',
                    'data': [{'name': p} for p in printers],
                    'printers': printers
                }
                resp_json = json.dumps(resp, ensure_ascii=False)
                print(f"[DEBUG] get_printers() 返回: {printers}")
                print(f"[DEBUG] WebSocket 发送: {resp_json}")
                await websocket.send(resp_json)
                continue
            # 兼容旧接口
            if data.get('method') == 'get_printers':
                printers = get_printers()
                await websocket.send(json.dumps({'status': 'ok', 'printers': printers}))
                continue

            if not PRINT_ALLOWED or PRINT_PAUSED:
                log('打印被暂停或禁止')
                await websocket.send(json.dumps({'status': 'error', 'message': '打印被暂停或禁止'}))
                continue
            pdf_url = data.get('pdfUrl') or data.get('PdfUrl')
            printer_name = data.get('printerName')
            
            # 强制所有打印任务都用 100*150mm 纸张
            paper_size = '100x150mm'

            if not pdf_url:
                log('打印失败：未提供pdfUrl')
                await websocket.send(json.dumps({'status': 'error', 'message': 'pdfUrl required'}))
                continue
            try:
                global is_printing
                is_printing = True
                if hasattr(start_gui, 'set_tray_blink'):
                    start_gui.set_tray_blink(True)
                
                # 参数类型校验
                if not isinstance(pdf_url, str) or (printer_name is not None and not isinstance(printer_name, str)):
                    log('参数类型错误，请检查接口调用方式。(WS)')
                    await websocket.send(json.dumps({'status': 'error', 'message': '参数类型错误，请检查接口调用方式。'}))
                    is_printing = False
                    if hasattr(start_gui, 'set_tray_blink'):
                        start_gui.set_tray_blink(False)
                    continue

                if pdf_url.startswith('http://') or pdf_url.startswith('https://'):
                    try:
                        temp_pdf = download_pdf(pdf_url)
                    except Exception as e:
                        await websocket.send(json.dumps({'status': 'error', 'message': str(e) + '（WebSocket端）'}))
                        is_printing = False
                        if hasattr(start_gui, 'set_tray_blink'):
                            start_gui.set_tray_blink(False)
                        continue
                else:
                    temp_pdf = os.path.join(CACHE_DIR, f"{uuid.uuid4()}.pdf")
                    try:
                        shutil.copy(pdf_url, temp_pdf)
                    except Exception as e:
                        log(f'本地PDF拷贝失败(WS)：{pdf_url}，错误：{str(e)}。请检查文件路径和权限。')
                        await websocket.send(json.dumps({'status': 'error', 'message': f'本地PDF拷贝失败：{str(e)}。建议：检查文件路径、权限。'}))
                        is_printing = False
                        if hasattr(start_gui, 'set_tray_blink'):
                            start_gui.set_tray_blink(False)
                        continue
                    clean_cache()
                
                # 构建打印命令 (使用 lp 命令进行打印)
                cmd = ['lp', '-o', f'PageSize={paper_size}']
                
                # 如果指定了打印机，则添加打印机参数
                if printer_name:
                    # 验证打印机是否存在
                    if printer_name not in get_printers():
                        log(f'打印机名称无效(WS)：{printer_name}。请检查打印机是否连接、名称是否正确。')
                        await websocket.send(json.dumps({'status': 'error', 'message': f'打印机名称无效：{printer_name}。建议：检查打印机连接和名称。'}))
                        is_printing = False
                        if hasattr(start_gui, 'set_tray_blink'):
                            start_gui.set_tray_blink(False)
                        continue
                    cmd.extend(['-d', printer_name])
                
                # 添加PDF文件路径
                cmd.append(temp_pdf)
                
                log(f'最终执行命令(WS): {" ".join(cmd)}')

                try:
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60, check=False)
                except subprocess.TimeoutExpired:
                    is_printing = False
                    if hasattr(start_gui, 'set_tray_blink'):
                        start_gui.set_tray_blink(False)
                    log(f'打印超时(WS)：{pdf_url}，建议检查打印机连接和状态。')
                    await websocket.send(json.dumps({'status': 'error', 'message': '打印超时，建议检查打印机连接和状态。'}))
                    continue
                except OSError as e:
                    is_printing = False
                    if hasattr(start_gui, 'set_tray_blink'):
                        start_gui.set_tray_blink(False)
                    log(f'打印命令无法执行(WS)，错误：{e}')
                    await websocket.send(json.dumps({'status': 'error', 'message': '打印命令无法执行，请检查系统打印服务。'}))
                    continue
                
                finally:
                    is_printing = False
                    if hasattr(start_gui, 'set_tray_blink'):
                        start_gui.set_tray_blink(False)

                if result.returncode == 0:
                    log(f'打印成功(WS)：{pdf_url} -> {printer_name or "默认打印机"} 纸张:{paper_size} 缓存:{temp_pdf}')
                    await websocket.send(json.dumps({'status': 'ok', 'message': result.stdout, 'cachePath': temp_pdf}))
                else:
                    err_msg = result.stderr.lower()
                    if 'invalid' in err_msg or 'corrupt' in err_msg:
                        log(f'PDF文件损坏或格式不受支持(WS)：{pdf_url}。建议重新生成或检查源文件。')
                        await websocket.send(json.dumps({'status': 'error', 'message': 'PDF文件损坏或格式不受支持，建议重新生成或检查源文件。', 'cachePath': temp_pdf}))
                        continue
                    
                    log(f'打印失败(WS)：{pdf_url} -> {printer_name or "默认打印机"}，错误：{result.stderr} 缓存:{temp_pdf}。建议：检查打印机状态、纸张、驱动。')
                    await websocket.send(json.dumps({'status': 'error', 'message': result.stderr + "。建议：检查打印机状态、纸张、驱动。", 'cachePath': temp_pdf}))
            except websockets.exceptions.ConnectionClosed:
                log('WebSocket 客户端已断开')
                break
            except Exception as e:
                is_printing = False
                if hasattr(start_gui, 'set_tray_blink'):
                    start_gui.set_tray_blink(False)
                log(f'打印异常(WS)：{pdf_url}，错误：{str(e)}。如多次出现此类错误，请联系技术支持。')
                try:
                    await websocket.send(json.dumps({'status': 'error', 'message': str(e) + "。如多次出现此类错误，请联系技术支持。"}))
                except websockets.exceptions.ConnectionClosed:
                    log('WebSocket 客户端已断开')
                    break
    except Exception as e:
        log(f'WebSocket连接异常：{str(e)}')

def start_ws_server():
    print(f"[DEBUG] WebSocket服务即将启动，监听端口: {WS_PORT}")
    import sys
    try:
        async def ws_main():
            try:
                async with websockets.serve(ws_handler, '127.0.0.1', WS_PORT):
                    print(f"[DEBUG] WebSocket服务已启动，监听端口: {WS_PORT}")
                    await asyncio.Future()  # run forever
            except OSError as e:
                # 只写一条简明日志，不重复输出异常堆栈
                log('WebSocket服务启动失败：端口被占用，请更换端口或关闭占用程序。重启软件后请按F5刷新打印网站。')
                print(f"[ERROR] WebSocket服务启动失败：端口被占用，请更换端口或关闭占用程序。重启软件后请按F5刷新打印网站。", file=sys.stderr)
        asyncio.run(ws_main())
    except Exception as e:
        print(f"[ERROR] WebSocket服务启动失败: {e}", file=sys.stderr)


def open_printer_settings():
    try:
        subprocess.Popen(['open', '-b', 'com.apple.systempreferences', '/System/Library/PreferencePanes/PrintAndScan.prefPane'])
    except Exception as e:
        messagebox.showerror("错误", f"无法打开打印机设置: {e}")

def start_gui():
    # 托盘闪烁控制
    tray_blinking = {'flag': False, 'thread': None}
    def tray_blink_worker():
        import time
        state = False
        while tray_blinking['flag']:
            if tray_icon_instance:
                tray_icon_instance.icon = tray_icons_pil['on'] if state else tray_icons_pil['off']
            state = not state
            time.sleep(0.5)
        # 恢复为当前状态
        if tray_icon_instance:
            if PRINT_ALLOWED and not PRINT_PAUSED:
                tray_icon_instance.icon = tray_icons_pil['on']
            else:
                tray_icon_instance.icon = tray_icons_pil['off']

    def set_tray_blink(blink):
        if blink:
            if not tray_blinking['flag']:
                tray_blinking['flag'] = True
                tray_blinking['thread'] = threading.Thread(target=tray_blink_worker, daemon=True)
                tray_blinking['thread'].start()
        else:
            tray_blinking['flag'] = False
    start_gui.set_tray_blink = set_tray_blink
    global root, status_icon_label, status_text_label, port_value_label, ws_port_value_label, logbox, tray_icon_instance, tk_icons, PRINT_ALLOWED, PRINT_PAUSED, tray_icons_pil
    root = tk.Tk()
    # 初始窗口标题
    def update_title():
        if PRINT_ALLOWED and not PRINT_PAUSED:
            root.title("本地静默打印服务 - 打印已启动")
        else:
            root.title("本地静默打印服务 - 打印已暂停")
    update_title()
    root.geometry("600x500")
    root.protocol("WM_DELETE_WINDOW", lambda: root.withdraw())  # 关闭按钮只隐藏窗口

    # 生成绿色/灰色圆形图标（PIL Image）
    def make_icon_pil(color, size=64):
        img = Image.new('RGBA', (size, size), (255, 255, 255, 0))
        draw = ImageDraw.Draw(img)
        draw.ellipse((8, 8, size-8, size-8), fill=color, outline=(128, 128, 128))
        return img

    tray_icons_pil = {
        'on': make_icon_pil((0, 255, 0)),
        'off': make_icon_pil((180, 180, 180))
    }

    # Tkinter用PhotoImage生成小圆点
    def make_icon_tk(color, size=18):
        img = Image.new('RGBA', (size, size), (255, 255, 255, 0))
        draw = ImageDraw.Draw(img)
        draw.ellipse((2, 2, size-2, size-2), fill=color, outline=(128, 128, 128))
        return ImageTk.PhotoImage(img, master=root)
    tk_icons['on'] = make_icon_tk((0, 255, 0))
    tk_icons['off'] = make_icon_tk((180, 180, 180))

    # 状态指示灯和文字（主窗口左上角）
    status_icon_label = tk.Label(root, image=tk_icons['on'])
    status_icon_label.place(x=20, y=10)
    status_text_label = tk.Label(root, text="打印已启动", font=("微软雅黑", 11, "bold"), fg="#00b300")
    status_text_label.place(x=50, y=10)

    # 端口信息（紧跟状态指示灯下方）
    tk.Label(root, text="HTTP端口:").place(x=20, y=50)
    port_value_label = tk.Label(root, text=str(PORT), fg="#0055cc", font=("微软雅黑", 10, "bold"))
    port_value_label.place(x=100, y=50)
    tk.Label(root, text="WebSocket端口:").place(x=20, y=80)
    ws_port_value_label = tk.Label(root, text=str(WS_PORT), fg="#0055cc", font=("微软雅黑", 10, "bold"))
    ws_port_value_label.place(x=120, y=80)

    def set_port_label(port):
        port_value_label.config(text=str(port))
    def set_ws_port_label(port):
        ws_port_value_label.config(text=str(port))
    start_gui.set_port_label = set_port_label
    start_gui.set_ws_port_label = set_ws_port_label

    # 日志显示
    tk.Label(root, text="实时打印日志:").place(x=20, y=170)
    logbox = tk.Text(root, height=15, width=70)
    logbox.place(x=20, y=200)

    def clear_log():
        try:
            with open(LOG_FILE, 'w', encoding='utf-8') as f:
                f.write("")
            logbox.delete(1.0, tk.END)
        except Exception as e:
            messagebox.showerror("错误", f"无法清空日志: {e}")

    def start_print():
        global PRINT_ALLOWED, PRINT_PAUSED
        PRINT_ALLOWED = True
        PRINT_PAUSED = False
        logbox.insert(tk.END, "[系统] 打印已启动\n")
        try:
            update_gui_status()
        except Exception:
            pass
    def pause_print():
        global PRINT_PAUSED
        PRINT_PAUSED = True
        logbox.insert(tk.END, "[系统] 打印已暂停\n")
        try:
            update_gui_status()
        except Exception:
            pass
    def stop_print():
        global tray_icon_instance
        if tray_icon_instance:
            tray_icon_instance.stop()
        root.quit()
        os._exit(0)

    btn_width = 12
    btn_gap = 20
    base_x = 20
    y_pos = 130
    tk.Button(root, text="开始打印", width=btn_width, command=start_print).place(x=base_x, y=y_pos)
    tk.Button(root, text="暂停打印", width=btn_width, command=pause_print).place(x=base_x + (btn_width+2)*7 + btn_gap, y=y_pos)
    tk.Button(root, text="退出打印", width=btn_width, command=stop_print).place(x=base_x + 2*((btn_width+2)*7 + btn_gap), y=y_pos)
    tk.Button(root, text="清空日志", width=btn_width, command=clear_log).place(x=base_x + 3*((btn_width+2)*7 + btn_gap), y=y_pos)
    start_print()

    tk.Label(root, text="缓存PDF目录(仅供核查):").place(x=20, y=460)
    def open_cache_dir():
        abs_path = os.path.abspath(CACHE_DIR)
        if not os.path.exists(abs_path):
            os.makedirs(abs_path, exist_ok=True)
        try:
            subprocess.run(['open', abs_path])
        except Exception as e:
            messagebox.showerror("错误", f"无法打开缓存目录: {e}")
    tk.Button(root, text="打开缓存目录", command=open_cache_dir).place(x=160, y=455)

    def refresh_log():
        try:
            with open(LOG_FILE, 'r', encoding='utf-8') as f:
                lines = f.readlines()[-100:]
            logbox.delete(1.0, tk.END)
            for line in lines:
                logbox.insert(tk.END, line)
        except:
            pass
        root.after(2000, refresh_log)
    refresh_log()

    def update_gui_status():
        global tray_icon_instance, status_icon_label, status_text_label, root, tk_icons, PRINT_ALLOWED, PRINT_PAUSED, tray_icons_pil
        tip = "（如遇异常重启软件后请按F5刷新打印网站）"
        if PRINT_ALLOWED and not PRINT_PAUSED:
            status_icon_label.config(image=tk_icons['on'])
            status_text_label.config(text="打印已启动 " + tip, fg="#00b300")
            root.title("本地静默打印服务 - 打印已启动 " + tip)
            if tray_icon_instance:
                tray_icon_instance.icon = tray_icons_pil['on']
                tray_icon_instance.title = "本地静默打印服务 - 打印已启动 " + tip
        else:
            status_icon_label.config(image=tk_icons['off'])
            status_text_label.config(text="打印已暂停 " + tip, fg="#888888")
            root.title("本地静默打印服务 - 打印已暂停 " + tip)
            if tray_icon_instance:
                tray_icon_instance.icon = tray_icons_pil['off']
                tray_icon_instance.title = "本地静默打印服务 - 打印已暂停 " + tip

    # 托盘相关
    def on_show_window(icon, item):
        root.after(0, lambda: root.deiconify())
    def on_start_print(icon, item):
        root.after(0, lambda: start_print())
    def on_pause_print(icon, item):
        root.after(0, lambda: pause_print())
    def on_exit(icon, item):
        if icon:
            icon.stop()
        root.after(0, lambda: root.quit())
    def on_status(icon, item):
        if PRINT_ALLOWED and not PRINT_PAUSED:
            icon.notify("打印已启动", "绿色灯亮")
        else:
            icon.notify("打印已暂停", "灰色灯")
    
    def tray_loop():
        global tray_icon_instance
        # 动态创建菜单项
        def create_menu():
            menu_items = [
                pystray.MenuItem('显示主窗口', on_show_window),
                pystray.MenuItem('开始打印', on_start_print),
                pystray.MenuItem('暂停打印', on_pause_print),
                pystray.MenuItem('显示当前状态', on_status),
                pystray.MenuItem('退出打印', on_exit)
            ]
            return pystray.Menu(*menu_items)

        tray_icon_instance = pystray.Icon("HttpPrinter", tray_icons_pil['on'], "本地静默打印服务", create_menu())
        tray_icon_instance.run()

    tray_thread = threading.Thread(target=tray_loop, daemon=True)
    tray_thread.start()

    # 启动时默认更新一次状态
    update_gui_status()

    root.mainloop()

if __name__ == '__main__':
    # 启动前清空日志文件，避免加载上一次的日志
    try:
        with open(LOG_FILE, 'w', encoding='utf-8') as f:
            f.write("")
    except Exception:
        pass
    # 先启动GUI（主线程，保证Tkinter/托盘/进度条正常）
    def start_servers():
        flask_thread = threading.Thread(target=run_flask, daemon=True)
        flask_thread.start()
        ws_thread = threading.Thread(target=start_ws_server, daemon=True)
        ws_thread.start()
    threading.Thread(target=start_servers, daemon=True).start()
    start_gui()